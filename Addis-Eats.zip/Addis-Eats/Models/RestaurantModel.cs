namespace AddisEats.Api.Model;


public class Restaurant
{
    public int Id { get; set; }
    public string Name { get; set; }
    public string Address { get; set; }
    public string Phone { get; set; }
    public bool IsActive { get; set; }
    public string OwnerAddress { get; set; }
}